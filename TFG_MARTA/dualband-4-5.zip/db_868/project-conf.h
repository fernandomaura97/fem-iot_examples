
#ifndef PROJECT_CONF_H_
#define PROJECT_CONF_H_
/*---------------------------*/
#define ZOUL_CONF_USE_CC1200_RADIO 1
#define IEEE802154_CONF_DEFAULT_CHANNEL 10

#endif /* PROJECT_CONF_H_ */
